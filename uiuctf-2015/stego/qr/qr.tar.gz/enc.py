#!/usr/bin/env python

from PIL import Image
import random

def get_color(x, y, r):
    n = (pow(x, 7) + pow(y, 8)) ^ r
    return (n ^ ((n >> 8) << 8))

flag_img = Image.open("durr.png")
im = flag_img.load()
r = random.randint(1, pow(2, 256))
g = random.randint(1, pow(2, 256))
b = random.randint(1, pow(2, 256))
print flag_img.size

enc_img = Image.new(flag_img.mode, flag_img.size)
enpix = enc_img.load()

for x in range(flag_img.size[0]):
    for y in range(flag_img.size[1]):
        m = random.randint(1, pow(2, 256)) % 250
        n = random.randint(1, pow(2, 256)) % 250
        p = random.randint(1, pow(2, 256)) % 250
        enpix[x,y] = (m, n, p)


for x in range(flag_img.size[0]):
    for y in range(flag_img.size[1]):
        s = enpix[x,y]
        a = ()
        if im[x,y][0] < 250:
            a += (get_color(x, y, r),)
        else:
            a += (enpix[x,y][0],)
        if im[x,y][1] < 250:
            a += (get_color(x, y, g),)
        else:
            a += (enpix[x,y][1],)
        if im[x,y][2] < 250:
            a += (get_color(x, y, b),)
        else:
            a += (enpix[x,y][2],)
        enpix[x,y] = a

enc_img.save('enc' + '.png')
