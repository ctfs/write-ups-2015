#!/usr/bin/python
#-*- coding:utf-8 -*-

import hashlib, sys, itertools

def creerGrille():
    result=[]
    for lignes in range(8):
        ligne=[]
        for colonne in range(8):
            ligne.append(0)
        result.append(ligne)
    return result

def genKey(key):
    psk=hashlib.sha256(key)
    buff=""
    seed=""
    for char in psk.hexdigest():
        buff+=bin(ord(char))[2:]
    for c in buff:
        seed+=c
    return seed

def initGrille(grille,seed):
    for (i, j), c in itertools.izip(itertools.product(xrange(len(grille)), reversed(xrange(len(grille[0])))), seed):
        grille[i][j] = c
    return grille
    
def tourSuivant(grille):
    tabbuff=[[0]*8 for _ in range(8)]
    for j in range(8):
        for i in range(8):
            voisine=0
            if grille[(j-1%8)][(i-1)%8] != '0':
                voisine+=1
            if grille[(j-1)%8][i] != '0':
                voisine+=1
            if grille[(j-1)%8][(i+1)%8] != '0':
                voisine+=1
            if grille[j][(i-1)%8] != '0':
                voisine+=1
            if grille[j][(i+1)%8] != '0':
                voisine+=1
            if grille[(j+1)%8][(i-1)%8] != '0':
                voisine+=1
            if grille[(j+1)%8][i] != '0':
                voisine+=1
            if grille[(j+1)%8][(i+1)%8] != '0':
                voisine+=1
            tabbuff[j][i]=voisine
        
    for j in range(8):
        for i in range(8):
            if tabbuff[j][i]==3 and grille[j][i]== '0':
                grille[j][i]='1'
            elif tabbuff[j][i] < 2 or tabbuff[j][i] > 3:
                grille[j][i]='0'
    return grille


def genBitstream(grille,key):
    bitstream=''
    for j in range(8):
        bitstream+=grille[j][7]
    return bitstream

def xor(ent1,ent2):
    key=itertools.cycle(ent2)
    return ''.join(chr(ord(x) ^ ord(y)) for (x,y) in itertools.izip(ent1, key))

def wrapper():
    key=sys.argv[1]
    fichier=open(sys.argv[2],'rb')
    encfile=''
    bitstream=''
    grille=initGrille(creerGrille(),genKey(key))
    for i in fichier.readlines():
        bitstream=genBitstream(grille,key)
        encfile+=xor(i,bitstream)
        tourSuivant(grille)
    print encfile

wrapper()
