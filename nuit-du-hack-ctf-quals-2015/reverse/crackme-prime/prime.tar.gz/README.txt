Crackme Prime

"I am Optimus Prime, and I send this
message to any surviving Autobots
taking refuge among the stars. We
are here, we are waiting."

Keygen me, I'm the Prime.
