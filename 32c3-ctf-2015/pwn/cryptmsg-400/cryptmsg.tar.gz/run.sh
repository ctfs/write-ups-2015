#!/bin/sh
cd cryptmsg
lighttpd -f lighttpd.conf -D
