#!/usr/bin/env python2

import json
from base64 import b64encode, b64decode
from sys import stdout
from os import environ
from urlparse import parse_qs
from Crypto.Cipher import AES

import cgitb
cgitb.enable()

GET = {key: value[-1] for key, value in parse_qs(environ["QUERY_STRING"]).items()}


def get_cipher():
    args = [GET.get("key"), int(GET.get("mode")), GET.get("iv", "")]
    return AES.new(*args)


cipher = get_cipher()

data = {
    "enc": cipher.encrypt,
    "dec": lambda s: cipher.decrypt(b64decode(s)),
}[GET.get("what")](GET.get("msg"))

stdout.write("Content-Type: application/json\r\n\r\n")
json.dump({"data": b64encode(data)}, stdout)
