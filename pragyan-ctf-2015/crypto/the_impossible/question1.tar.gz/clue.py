#!/usr/bin/python

i = 1
while (i>0):
	print i
	i = i + 1

# i feel so sad for you if you couldn't find the clue :-(
