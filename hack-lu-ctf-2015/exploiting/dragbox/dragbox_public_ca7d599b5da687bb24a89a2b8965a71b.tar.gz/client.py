# python3 module for connecting to Dragbox

import struct
import socket

SERVER = '149.13.33.84'
PORT = 1526

class BoxConnection:
  def __init__(self):
    self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    self.s.connect((SERVER, PORT))

  def sendcmd(self, cmd):
    self.s.send(struct.pack('I', cmd))

  def sendstr(self, str):
    data = bytearray(str, 'utf-8')
    self.s.send(struct.pack('I', len(data)))
    self.s.send(data)

  def recvstr(self):
    lenbytes = self.s.recv(4, socket.MSG_WAITALL)
    assert len(lenbytes) == 4
    [strlen] = struct.unpack('I', lenbytes)
    str = self.s.recv(strlen, socket.MSG_WAITALL).decode('utf-8')
    #print('got string: "{0}"'.format(str))
    return str

  def register(self, user, passw):
    self.sendcmd(1)
    self.sendstr(user)
    self.sendstr(passw)
    assert self.recvstr() == 'user created'

  def newshare(self, user, passw, share):
    self.sendcmd(2)
    self.sendstr(user)
    self.sendstr(passw)
    self.sendstr(share)
    assert self.recvstr() == 'share created'

  def openshare(self, user, share):
    self.sendcmd(3)
    self.sendstr(user)
    self.sendstr(share)
    assert self.recvstr() == 'go ahead'

  def fs_read(self, path):
    self.sendcmd(1)
    self.sendstr(path)
    return self.recvstr()

  def fs_write(self, path, data):
    self.sendcmd(2)
    self.sendstr(path)
    self.sendstr(data)
    return self.recvstr() == 'write successful'

  def fs_list(self, path):
    self.sendcmd(3)
    self.sendstr(path)
    names = []
    while True:
      str = self.recvstr()
      if len(str) == 0:
        break
      names.append(str)
    return names

  def fs_mkdir(self, path):
    self.sendcmd(4)
    self.sendstr(path)
    assert self.recvstr() == 'success'

  def fs_chdir(self, path):
    self.sendcmd(5)
    self.sendstr(path)
    assert self.recvstr() == 'success'

  def fs_pwd(self):
    self.sendcmd(6)
    return self.recvstr()

  def fs_rename(self, old, new):
    self.sendcmd(7)
    self.sendstr(old)
    self.sendstr(new)
    assert self.recvstr() == 'success'
