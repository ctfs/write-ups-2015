// gcc -o dragbox dragbox.c -std=gnu99

#define PORT 1526
#define ROOTDIR "./data"

#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define error(x) (fputs(x "\n", stderr), exit(1))
#define streq(a, b) (strcmp((a), (b)) == 0)

int negchke(int n, const char *err) {
  if (n < 0) {
    perror(err);
    exit(1);
  }
  return n;
}

void xrecv(int fd, void *buf, size_t len) {
  if (recv(fd, buf, len, MSG_WAITALL) != len)
    error("short read");
}

void xwrite(int fd, const void *buf, size_t len) {
  if (write(fd, buf, len) != len)
    error("short write");
}

#define BUFSIZE 200

/* read length-prefixed string, write it to buf as a c-string.
 * buf must be BUFSIZE bytes. */
void readstr(int fd, char *buf) {
  unsigned int len;
  xrecv(fd, &len, sizeof(len));
  if (len >= BUFSIZE) error("string length too big");
  xrecv(fd, buf, len);
  buf[len] = '\0';
}

/* read a folder- or filename */
void readname(int fd, char *buf) {
  readstr(fd, buf);
  if (buf[0] == '\0')
    error("user sent an empty name");
  if (strchr(buf, '/') != NULL)
    error("user sent a name with a slash");
  if (streq(buf, ".") || streq(buf, ".."))
    error("user sent \".\" or \"..\" as name");
}

int client_fd;

void sendstr(const char *str) {
  unsigned int len = strlen(str);
  xwrite(client_fd, &len, sizeof(len));
  xwrite(client_fd, str, len);
}
#define writeend(...) (sendstr(__VA_ARGS__), exit(0))

void writefile(const char *path, void *buf, size_t len) {
  /* horrible kludge for messed-up headers */
  #ifndef O_TMPFILE
  #define O_TMPFILE (020000000 | O_DIRECTORY)
  #endif

  int fd = negchke(open(".", O_RDWR|O_TMPFILE, 0600), "unable to create tempfile");
  xwrite(fd, buf, len);
  negchke(linkat(fd, "", AT_FDCWD, path, AT_EMPTY_PATH), "unable to link file to destination");
}

void readfile(const char *path, char *buf) {
  int fd = negchke(open(path, O_RDONLY), "unable to open file for reading");
  int len = negchke(read(fd, buf, BUFSIZE-1), "read from local file failed");
  buf[len] = '\0';
}

enum request_type {
  request_register = 1,
  request_newshare = 2,
  request_openshare = 3
};

enum fs_request_type {
  fs_request_read = 1,
  fs_request_write = 2,
  fs_request_list = 3,
  fs_request_mkdir = 4,
  fs_request_chdir = 5,
  fs_request_pwd = 6,
  fs_request_rename = 7
};

__attribute__((optimize(0), noinline, noclone))
int passwords_equal(const char *a, const char *b) {
  size_t alen = strlen(a), blen = strlen(b);
  if (alen != blen) return 0;
  char x = 0;
  for (size_t i=0; i<alen; i++) {
    x |= a[i] ^ b[i];
  }
  return x == 0;
}

/* temp printf */
char *tprintf(const char *fmt, ...) {
  static char buf[BUFSIZE];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(buf, BUFSIZE, fmt, ap);
  va_end(ap);
  return buf;
}

void auth_user(char *user) {
  readname(client_fd, user);
  if (access(user, F_OK))
    writeend("user not found");

  char pass[BUFSIZE];
  readstr(client_fd, pass);
  char real_pass[BUFSIZE];
  readfile(tprintf("%s/password", user), real_pass);
  if (!passwords_equal(pass, real_pass))
    writeend("wrong password");
}

void handle_fs_requests(void) {
  char path[BUFSIZE];
  char buf[1024*1024]; /* large buffer because files might be large */
  while (1) {
    enum fs_request_type type;
    xrecv(client_fd, &type, sizeof(type));
    switch (type) {
      case fs_request_read: {
        readstr(client_fd, path);
        struct stat st;
        if (stat(path, &st)) {
          sendstr("file not found");
          continue;
        }
        int fd = negchke(open(path, O_RDONLY), "open for read request");
        unsigned int len = negchke(read(fd, buf, sizeof(buf)), "read for read request");
        xwrite(client_fd, &len, sizeof(len));
        xwrite(client_fd, buf, len);
        close(fd);
        continue;
      }
      case fs_request_write: {
        readstr(client_fd, path);
        int fd = open(path, O_WRONLY|O_CREAT|O_TRUNC);
        if (fd == -1) {
          sendstr("path not found");
          continue;
        }
        unsigned int len;
        xrecv(client_fd, &len, sizeof(len));
        if (len > sizeof(buf)) {
          sendstr("bad length");
          return;
        }
        xrecv(client_fd, buf, len);
        xwrite(fd, buf, len);
        close(fd);
        sendstr("write successful");
        continue;
      }
      case fs_request_list: {
        readstr(client_fd, path);
        DIR *d = opendir(path);
        if (!d) {
          sendstr("path not found");
          sendstr("");
          continue;
        }
        struct dirent *dent;
        while ((dent = readdir(d))) {
          sendstr(dent->d_name);
        }
        sendstr("");
        continue;
      }
      case fs_request_mkdir: {
        readstr(client_fd, path);
        sendstr(mkdir(path, 0700) ? "unable to create directory" : "success");
        continue;
      }
      case fs_request_chdir: {
        readstr(client_fd, path);
        sendstr(chdir(path) ? "unable to change directory" : "success");
        continue;
      }
      case fs_request_pwd: {
        char *cwd = getcwd(NULL, 0);
        sendstr(cwd ? cwd : "<error>");
        free(cwd);
        continue;
      }
      case fs_request_rename: {
        char oldname[BUFSIZE];
        char newname[BUFSIZE];
        readstr(client_fd, oldname);
        readstr(client_fd, newname);
        sendstr(rename(oldname, newname) ? "unable to rename" : "success");
        continue;
      }
      default: {
        writeend("bad request");
      }
    }
  }
}

void handle_request(void) {
  alarm(60);

  char user[BUFSIZE];
  char pass[BUFSIZE];
  char share[BUFSIZE];

  enum request_type type;
  xrecv(client_fd, &type, sizeof(type));
  switch (type) {
    case request_register: {
      readname(client_fd, user);
      readstr(client_fd, pass);

      if (mkdir(user, 0700)) {
        if (errno == EEXIST)
          writeend("that username already exists");
        error("unable to create user dir");
      }
      writefile(tprintf("%s/password", user), pass, strlen(pass));
      negchke(mkdir(tprintf("%s/shares", user), 0700), "unable to create shares dir");
      writeend("user created");
    }

    case request_newshare: {
      auth_user(user);
      readname(client_fd, share);
      if (mkdir(tprintf("%s/shares/%s", user, share), 0700)) {
        if (errno == EEXIST)
          writeend("that share already exists");
        error("unable to create share");
      }
      writeend("share created");
    }

    case request_openshare: {
      readname(client_fd, user);
      readname(client_fd, share);
      if (chroot(tprintf("%s/shares/%s", user, share))) {
        if (errno == ENOENT)
          writeend("share not found");
        error("unable to open share");
      }
      negchke(chdir("/"), "chdir / failed???");
      sendstr("go ahead");
      handle_fs_requests();
      return;
    }

    default: writeend("bad command");
  };
}

int main(void) {
  if (geteuid() != 0 && !getenv("I_SET_THE_CAPS_SHUT_UP"))
    error("this server needs CAP_DAC_READ_SEARCH and CAP_SYS_CHROOT - just run it as root");

  int ssock = negchke(socket(AF_INET6, SOCK_STREAM, 0), "unable to create socket");
  struct sockaddr_in6 addr = {
    .sin6_family = AF_INET6,
    .sin6_port = htons(PORT),
    .sin6_addr = IN6ADDR_ANY_INIT
  };
  int one = 1;
  negchke(setsockopt(ssock, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)), "unable to set SO_REUSEADDR");
  negchke(bind(ssock, (struct sockaddr *)&addr, sizeof(addr)), "unable to bind");
  negchke(listen(ssock, 16), "unable to listen");

  negchke(chdir(ROOTDIR), "unable to chdir");
  signal(SIGCHLD, SIG_IGN);

  while (1) {
    client_fd = negchke(accept(ssock, NULL, NULL), "unable to accept");
    pid_t pid = negchke(fork(), "unable to fork");
    if (pid == 0) {
      close(ssock);
      handle_request();
      return 0;
    }
    close(client_fd);
  }
}