#!/usr/bin/env node
var http = require('http');
var fs = require('fs');
var verifier = require('./verifier.js');
var verify_game = verifier.verify_game;

// I *really* don't want a directory traversal vuln or so.
var static_files = Object.create(null);
'tiles/F.png,tiles/L.png,tiles/X.png,tiles/boots.png,tiles/lazor.png,tiles/marcher_l.png,tiles/marcher_r.png,tiles/player.png,tiles/player_with_boots.png,champion.css,champion.html,merged.js,world.txt'.split(',').forEach(function(name) {
  static_files['FILE_/'+name] = fs.readFileSync(name);
});
static_files['FILE_/'] = static_files['FILE_/champion.html'];

var flag_ticks_limit = 5000;
var flag = fs.readFileSync('flag', 'utf8');

var highscore = [];
try {
  highscore = JSON.parse(fs.readFileSync('highscore.save', 'utf8'));
} catch (e) {}
setInterval(function() { fs.writeFileSync('highscore.save_', JSON.stringify(highscore)); fs.renameSync('highscore.save_', 'highscore.save') }, 10000);

var server = http.createServer(function(req, res) {
  function reply(code, text) {
    res.writeHead(code);
    res.end(text);
  }

  var file = static_files['FILE_'+req.url];
  if (file) {
    reply(200, file);
  } else if (req.url == '/scoreboard') {
    res.writeHead(200, {
      'Content-Type': 'text/plain; charset=utf-8',
      'Refresh': '30' /////////////////////////// EDIT IF THIS BECOMES A PERF PROBLEM
    });
    res.end(highscore.map(function(o, i) {
      return (i + 1 + 1000).toString().slice(-3) + ' ' + (o.count + 1000000).toString().slice(-6) + ' ' + o.name;
    }).join('\n'))
  } else if (req.url == '/submit' && req.method == 'POST') {
    if (req.headers['genuine'] !== 'yes') {
      reply(403, 'request is not genuine');
      return;
    }
    var body = [];
    var body_size = 0;
    req.setEncoding('utf8');
    req.on('data', function(chunk) {
      if (body == null) return;
      body.push(chunk);
      body_size += chunk.length;
      if (body_size > 100000) {
        body = null;
        reply(400, 'request too large');
      }
    });
    req.on('end', function() {
      if (body == null) return;
      body = body.join('').split('\n');
      if (body.length !== 2) return reply(400, 'bad body format, expected replay\\nname');
      var replay = body[0];
      var name = body[1];
      if (name.length > 50) return reply(400, 'name must be <=50 chars');
      if (name.replace(/[a-zA-Z0-9_ -]/g, '').length !== 0) return reply(400, 'name must be ASCII alphanumeric or so');
      var t_start = Date.now();
      verify_game(replay, function(win_count, text) {
        var t_end = Date.now();
        console.log(t_start, t_end);
        console.log('verification took ' + (t_end - t_start) + 'ms, win_count: '+win_count);
        if (win_count == -1) {
          console.log('rejected replay: '+text)
          return reply(400, 'bad replay string: ' + text);
        }

        // add highscore entry logic
        for (var i=0; i<100; i++) {
          if (!highscore[i]) {
            highscore.push({count: win_count, name: name});
            break;
          }
          if (win_count < highscore[i].count) {
            highscore.splice(i, 0, {count: win_count, name: name});
            break;
          }
        }
        if (highscore.length >= 100) highscore.pop();

        if (win_count > flag_ticks_limit)
          reply(200, 'nice! you won after '+win_count+' ticks. that is above '+flag_ticks_limit+' though - try to be faster.')
        else
          reply(200, 'yay, you did it, in only '+win_count+' ticks! this is the flag: '+flag);
      });
    });
  } else {
    res.writeHead(404);
    res.end('not found');
  }
});
verifier.load_tiles(function() {
  server.listen(1504, '0.0.0.0');
});
server.timeout = 15000; /* 15 seconds */
server.maxHeadersCount = 100;