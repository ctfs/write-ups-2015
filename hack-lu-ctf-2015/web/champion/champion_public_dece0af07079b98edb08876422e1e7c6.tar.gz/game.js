var worldobj = new World();
STARTBROWSERONLY
var stored_input;
ENDBROWSERONLY
worldobj.cb_result = (typeof cb_result === 'function' ? cb_result : null);