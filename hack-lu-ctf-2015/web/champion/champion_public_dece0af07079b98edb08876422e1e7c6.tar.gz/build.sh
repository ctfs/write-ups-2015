#!/bin/bash
(
  cat game_static.js | sed 's|STARTBROWSERONLY|/*STARTBROWSERONLY|' | sed 's|ENDBROWSERONLY|ENDBROWSERONLY*/|' | sed 's|STARTNODEONLY|/*STARTNODEONLY*/|' | sed 's|ENDNODEONLY|/*ENDNODEONLY*/|' | sed 's|CBARG||' | sed 's|CBRET|return|'
  echo
  cat verifier_gamecode_static.js
  echo
  echo 'exports.verify_game = function run_verification_game(game_input, cb_result) {'
  (
    cat game.js | sed 's|STARTBROWSERONLY|/*STARTBROWSERONLY|' | sed 's|ENDBROWSERONLY|ENDBROWSERONLY*/|' | sed 's|STARTNODEONLY|/*STARTNODEONLY*/|' | sed 's|ENDNODEONLY|/*ENDNODEONLY*/|' | sed 's|CBARG||' | sed 's|CBRET|return|'
    echo
    cat verifier_gamecode.js
    echo
  ) | sed 's|^|  |g'
  echo '};'
) > verifier.js

(
  cat game_static.js
  echo
  cat game.js
  echo
  cat champion.js
) | sed 's|STARTBROWSERONLY|/*STARTBROWSERONLY*/|' | sed 's|ENDBROWSERONLY|/*ENDBROWSERONLY*/|' | sed 's|STARTNODEONLY|/*STARTNODEONLY|' | sed 's|ENDNODEONLY|ENDNODEONLY*/|' | sed 's|CBARG|, cb|' | sed 's|CBRET|cb|' > merged.js