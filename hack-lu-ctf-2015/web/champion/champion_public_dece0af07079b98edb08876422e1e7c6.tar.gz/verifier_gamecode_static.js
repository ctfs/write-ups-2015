var crypto = require('crypto');
var fs = require('fs');
var PNG = require('node-png').PNG;

function sha512(input) {
  var h = crypto.createHash('sha512');
  h.update(input, 'utf8');
  return [].slice.call(h.digest());
}

function NodeImage(width, height) {
  this.width = width;
  this.height = height;
  this.halfheight = height / 2;
  this.halfwidth = width / 2;
}

function load_img(path, cb) {
  fs.createReadStream(path).pipe(new PNG()).on('parsed', function() {
    var img = new NodeImage(this.width, this.height);
    console.log('loaded '+path+': '+img.width+'x'+img.height)
    cb(img);
  });
}

function get(path) {
  return require('fs').readFileSync(path, 'utf8');
}

exports.load_tiles = load_tiles;

function dead(reason, w) {
  w.cb_result(-1, 'invalid replay, you died in tick '+w.current_tick+': '+reason);
}

function win(w) {
  w.cb_result(w.current_tick);
}

function end_of_replay(w) {
  w.cb_result(-1, 'invalid replay, ends before you win or die (in tick '+w.current_tick+')');
}