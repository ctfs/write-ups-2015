loadworld(worldobj);
var replay_ret = load_replay(worldobj, game_input);
if (replay_ret) {
  cb_result(-1, 'unable to process replay: '+replay_ret);
  return;
}
var break_tick = false;
while (!break_tick) {
  worldobj.current_tick++;
  // relies on the callback being synchronous
  tick(worldobj, function(cont) {
    if (!cont) {
      break_tick = true;
    }
  });
}