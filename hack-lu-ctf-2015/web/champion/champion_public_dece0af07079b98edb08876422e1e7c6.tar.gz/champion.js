function upload_result(name, replaystr) {
  var req = new XMLHttpRequest();
  req.open('POST', '/submit', false);
  req.setRequestHeader('Genuine', 'yes');
  req.send(replaystr + '\n' + name);
  alert((req.status == 200 ? 'upload successful' : 'upload failed') + '\n' + req.responseText);
}

var $ = document.getElementById.bind(document);

var canvas;
var in_tick = false;

function do_tick() {
  if (in_tick) return; /* skip frame */
  in_tick = true;
  tick(worldobj, function do_tick_() {
    in_tick = false
  });
}

document.addEventListener('DOMContentLoaded', function on_content_loaded() {
  load_tiles(function tiles_loaded() {
    loadworld(worldobj);

    canvas = $('output');
    $('btn_reset').onclick = function reset_btn_cb() {
      stop_and_reload(function reset_btn_cb_() {
        stored_input = [];
        start();
      });
    };
    $('btn_load').onclick = function load_btn_cb() {
      stop_and_reload(function load_btn_cb_() {
        load_replay(worldobj, $('replay_inout').value);
        stored_input = null;
        start();
      });
    };
    stored_input = [];
    start();
  });
});

function stop_and_reload(cb) {
  clearInterval(tick_interval);
  function stop_and_reload_() {
    // wheee, polling! don't kill me please.
    if (in_tick) return setTimeout(stop_and_reload_, 10);
    worldobj = new World();
    loadworld(worldobj);
    cb();
  }
  stop_and_reload_();
}

function start() {
  tick_interval = setInterval(do_tick, 20);
}

// there should really be a sync api for this.  srsly, hashing is not
// that slow.
function sha512(input, cb) {
  input = new TextEncoder("utf-8").encode(input);
  crypto.subtle.digest("SHA-512", input).then(function sha512_(hash){
    cb([].slice.call(new Uint8Array(hash)));
  });
}

function load_img(path, cb) {
  var img = new Image();
  img.onload = function load_img_() {
    img.halfheight = img.height / 2;
    img.halfwidth = img.width / 2;
    cb(img);
  };
  img.src = path;
}

var KEYS = {37:'left',38:'up',39:'right',40:'down'};
document.onkeydown = function onkeydown(e) {
  var key = KEYS[e.keyCode];
  if (key) worldobj.pressed[key] = true;
};
document.onkeyup = function onkeydown(e) {
  var key = KEYS[e.keyCode];
  if (key) worldobj.pressed[key] = false;
}

function get(path) {
  var req = new XMLHttpRequest();
  req.open('GET', path, false);
  req.send();
  return req.responseText;
}

function render() {
  var ctx = canvas.getContext('2d');
  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  for (var relx = 0; relx < WIDTH_IN_TILES; relx++) {
    for (var rely = 0; rely < HEIGHT_IN_TILES; rely++) {
      var tile = (worldobj.world[worldobj.offY + rely] || [])[worldobj.offX + relx];
      if (tile && tiles[tile]) {
        var img = tiles[tile];
        ctx.drawImage(img, relx * TILESIZE + (TILESIZE-img.width)/2, rely * TILESIZE + (TILESIZE-img.height) / 2);
      }
    }
  }
  worldobj.entities.forEach(function draw_entity(ent) {
    if (!ent.img || ent.img.length == 1) return;
    var img = tiles[ent.img];
    if (!img) return;
    var centerX = ent.x - worldobj.offX * TILESIZE;
    var centerY = ent.y - worldobj.offY * TILESIZE;
    ctx.drawImage(img, centerX - img.width/2, centerY - img.height/2);
  });
}

function dead() {
  clearInterval(tick_interval);
  alert('you lost! :(');
}

function win() {
  clearInterval(tick_interval);
  alert('you won' + stored_input ? ('after '+stored_input.length+' ticks! going to upload...') : '');
  if (stored_input) {
    var replaystr = encode_replay(stored_input);
    var name = prompt('your name? (will appear in public highscore, <=50 chars, only [a-zA-Z0-9_ -])');
    if (name != null) {
      upload_result(name, replaystr);
    }
    $('replay_inout').value = replaystr;
  }
}

function end_of_replay() {
  clearInterval(tick_interval);
  alert('replay ended without win/lose')
}

var tick_interval;