$ ./cryptooo SECCON{                        }
Encrypted(44): waUqjjDGnYxVyvUOLN8HquEO0J5Dqkh/zr/3KXJCEnw=
what's the key?
