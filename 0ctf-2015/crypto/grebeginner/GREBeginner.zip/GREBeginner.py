#!/usr/bin/python

"""
	GRE = Generic Random Encryption
"""

import sys, hashlib, struct
from optparse import OptionParser

P = 0x7914a5a5c4e094437977
K = 0

A, B, C = struct.unpack('>IQQ', hashlib.sha1('0ops').digest()) # generic random coefficients

def pr():
	global K, A, B, C
	K = ((A * K % P + B) * K + C) % P
	return K

def genkey(k):
	h = int(hashlib.sha256(k).hexdigest(), 16)
	r = 0
	while h > 0:
		r ^= h % 0x133337
		h /= 0x133337
	return r

def stream(n):
	s = ''
	for i in xrange(0, n, 4):
		s += struct.pack('<I', pr() & 0xffffffff)
	return s

if __name__ == '__main__':

	parser = OptionParser()
	parser.add_option('-k', '--key', dest="key", help="secret key")
	parser.add_option('-i', '--input', dest="infile", help="input file")
	parser.add_option('-o', '--output', dest="outfile", help="output file")
	parser.add_option('-m', '--mode', dest="mode", help="encode / decode")

	options, args = parser.parse_args()

	if not options.key or not options.infile or not options.outfile:
		parser.print_help()
		exit(0)
	
	K = genkey(options.key)

	# no brute force :)
	
	for i in xrange(0x1333337): # 0 x 1333337 is not zero
		pr()

	infile = open(options.infile, 'r').read()

	s = stream(len(infile))

	c = ''.join(map(chr, [ord(a) ^ ord(b) for a, b in zip(infile, s)]))

	open(options.outfile, 'w').write(c)
