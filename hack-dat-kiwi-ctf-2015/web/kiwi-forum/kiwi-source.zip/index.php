<html>
<head>

</head>
<body>
<form method='post'>
	<input type='text' name='username' placeholder='username' value=''/>
	<br/>
	<input type='password' name='password' />
	<br/>
	<input type='submit' value='Login'/>
	<a href='signup'>Sign Up</a>
</body>
</html>

