<?php
$dbhost = 'localhost';
$dbuser = '*****';
$dbpass = '*****';
$dbname = 'hackers_db';

$conn = mysql_connect($dbhost, $dbuser, $dbpass);
mysql_select_db($dbname);

?>
