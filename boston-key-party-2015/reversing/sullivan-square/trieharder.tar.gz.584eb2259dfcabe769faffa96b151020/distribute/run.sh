rbx -I. -e "Rubinius::CodeLoader.require_compiled 'trie_harder'"
