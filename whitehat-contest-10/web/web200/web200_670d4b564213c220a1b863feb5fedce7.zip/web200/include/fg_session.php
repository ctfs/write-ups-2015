<?php
// custom session handler
class FGSession {
	
	var $sess_encrypt_cookie		= FALSE;
	var $sess_expiration			= 7200;
	var $sess_expire_on_close		= FALSE;
	var $sess_match_ip				= TRUE;
	var $sess_match_useragent		= TRUE;
	var $sess_cookie_name			= 'fg_session';
	var $cookie_prefix				= '';
	var $cookie_path				= '';
	var $cookie_domain				= '';
	var $cookie_secure				= FALSE;
	var $sess_time_to_update		= 300;
	var $encryption_key				= '';
	var $time_reference				= 'time';
	var $userdata					= array();
	var $now;
	var $magic_byte = 0x41;
	
	public function __construct($params = array())
	{
		foreach (array('sess_encrypt_cookie', 'sess_expiration', 'sess_expire_on_close', 'sess_match_ip', 'sess_match_useragent', 'sess_cookie_name', 'cookie_path', 'cookie_domain', 'cookie_secure', 'sess_time_to_update', 'time_reference', 'cookie_prefix', 'encryption_key') as $key)
		{
			if(isset($params[$key])){
				$this->$key = $params[$key];
			}
		}
		if ($this->encryption_key == '')
		{
			die('encryption_key not set');
		}
		
		$this->now = $this->_get_time();
		
		if ($this->sess_expiration == 0)
		{
			$this->sess_expiration = (60*60*24*365*2);
		}

		$this->sess_cookie_name = $this->cookie_prefix.$this->sess_cookie_name;
		

		
		if ( ! $this->read())
		{
			$this->_create();
		}
		else
		{
			$this->_update();
		}
		
	}
	
	public function setEncryptionKey($key){
		$this->encryption_key = $key;
	}
	
	function destroy()
	{
		setcookie($this->sess_cookie_name,
			addslashes(serialize(array())),
			($this->now - 31500000),
			$this->cookie_path,
			$this->cookie_domain,
			0);
		return TRUE;
	}
	
	function read()
	{
		$session = '';
		if(isset($_COOKIE[$this->sess_cookie_name])){
			$session = $_COOKIE[$this->sess_cookie_name];
		}
		if ($session === '')
		{
			return FALSE;
		}
		
		if ($this->sess_encrypt_cookie == TRUE)
		{
			$session = $this->_decode($session);
		}
		else
		{
			
			$hash	 = substr($session, strlen($session)-32); // get last 32 chars
			$session = substr($session, 0, strlen($session)-32);
			
			if ($hash !==  md5($session.$this->encryption_key))
			{
				$this->destroy();
				die('The session cookie data did not match what was expected. This could be a possible hacking attempt.');
			}
		}

		$session = $this->_unserialize($session);

		if ( ! is_array($session) OR ! isset($session['session_id']) OR ! isset($session['ip_address']) OR ! isset($session['user_agent']) OR ! isset($session['last_activity']))
		{
			$this->destroy();
			return FALSE;
		}
		
		if (($session['last_activity'] + $this->sess_expiration) < $this->now)
		{
			$this->destroy();
			return FALSE;
		}
		
		if ($this->sess_match_ip == TRUE AND $session['ip_address'] != $_SERVER['REMOTE_ADDR'])
		{
			$this->destroy();
			return FALSE;
		}
		
		if ($this->sess_match_useragent == TRUE AND trim($session['user_agent']) != trim(substr($_SERVER['HTTP_USER_AGENT'], 0, 120)))
		{
			$this->destroy();
			return FALSE;
		}
		
		$this->userdata = $session;
		
		unset($session);
		return TRUE;
	}
	
	function write()
	{
		$this->_set_cookie();	
	}

	function get($item)
	{
		return ( ! isset($this->userdata[$item])) ? NULL : $this->userdata[$item];
	}
	
	function set($newdata = array(), $newval = '')
	{
		if (is_string($newdata))
		{
			$newdata = array($newdata => $newval);
		}
		if (count($newdata) > 0)
		{
			foreach ($newdata as $key => $val)
			{
				$this->userdata[$key] = $val;
			}
		}
		$this->write();
	}
	
	function uset($newdata = array())
	{
		if (is_string($newdata))
		{
			$newdata = array($newdata => '');
		}
		if (count($newdata) > 0)
		{
			foreach ($newdata as $key => $val)
			{
				unset($this->userdata[$key]);
			}
		}
		$this->write();
	}
	
	function _create()
	{
		$sessid = '';
		while (strlen($sessid) < 32)
		{
			$sessid .= mt_rand(0, mt_getrandmax());
		}
		$sessid .= $_SERVER['REMOTE_ADDR'];
		$this->userdata = array(
				'session_id'	=> md5(uniqid($sessid, TRUE)),
				'ip_address'	=> $_SERVER['REMOTE_ADDR'],
				'user_agent'	=> substr($_SERVER['HTTP_USER_AGENT'], 0, 120),
				'last_activity'	=> $this->now,
				'user_data'		=> ''
		);
		$this->_set_cookie();
	}
	
	function _update()
	{
		if (($this->userdata['last_activity'] + $this->sess_time_to_update) >= $this->now)
		{
			return;
		}
		$new_sessid = '';
		while (strlen($new_sessid) < 32)
		{
			$new_sessid .= mt_rand(0, mt_getrandmax());
		}
		$new_sessid .= $_SERVER['REMOTE_ADDR'];
		$new_sessid = md5(uniqid($new_sessid, TRUE));
		$this->userdata['session_id'] = $new_sessid;
		$this->userdata['last_activity'] = $this->now;
		$this->_set_cookie();
	}
	
	function _get_time()
	{
		if (strtolower($this->time_reference) == 'gmt')
		{
			$now = time();
			$time = mktime(gmdate("H", $now), gmdate("i", $now), gmdate("s", $now), gmdate("m", $now), gmdate("d", $now), gmdate("Y", $now));
		}
		else
		{
			$time = time();
		}
		return $time;
	}
	
	function _set_cookie($cookie_data = NULL)
	{
		if (is_null($cookie_data))
		{
			$cookie_data = $this->userdata;
		}
		
		$cookie_data = $this->_serialize($cookie_data);
		if ($this->sess_encrypt_cookie == TRUE)
		{
			$cookie_data = $this->_encode($cookie_data);
		}
		else
		{
			$cookie_data = $cookie_data.md5($cookie_data.$this->encryption_key);
		}
		$expire = ($this->sess_expire_on_close === TRUE) ? 0 : $this->sess_expiration + time();
		
		setcookie(
			$this->sess_cookie_name,
			$cookie_data,
			$expire,
			$this->cookie_path,
			$this->cookie_domain,
			$this->cookie_secure
		);
	}
	
	function _serialize($data)
	{
		if (is_array($data))
		{
			foreach ($data as $key => $val)
			{
				if (is_string($val))
				{
					$data[$key] = str_replace('\\', '{{slash}}', $val);
				}
			}
		}
		else
		{
			if (is_string($data))
			{
				$data = str_replace('\\', '{{slash}}', $data);
			}
		}
		return serialize($data);
	}
	
	function _unserialize($data)
	{
		$data = unserialize(stripslashes($data));
		if (is_array($data))
		{
			foreach ($data as $key => $val)
			{
				if (is_string($val))
				{
					$data[$key] = str_replace('{{slash}}', '\\', $val);
				}
			}
			return $data;
		}
		return (is_string($data)) ? str_replace('{{slash}}', '\\', $data) : $data;
	}
	
	function _encode($string){
		$enc = $this->_xor_encode($string, $this->encryption_key);
		return base64_encode($enc);
	}
	
	function _decode($string){
		if (preg_match('/[^a-zA-Z0-9\/\+=]/', $string))
		{
			return FALSE;
		}
		$dec = base64_decode($string);
		return $this->_xor_decode($dec, $this->encryption_key);
	}
	
	
	
	function _xor_encode($string, $key) { 
		$rand = ''; 
		while (strlen($rand) < 32) { 
			$rand .= mt_rand(0, mt_getrandmax()); 
		} 
		$rand = sha1($rand); 
		$enc = ''; 
		for ($i = 0; $i < strlen($string); $i++) { 
			$ch = (substr($rand, ($i % strlen($rand)), 1) ^ substr($string, $i, 1)) ^ chr($this->magic_byte);
			$ch = substr($rand, ($i % strlen($rand)), 1). $ch ; 
			//$ch = ($ch ^ chr($this->magic_byte));
			$enc .= $ch;
		} 
		return $this->_xor_merge($enc, $key); 
	} 
	
	function _xor_decode($string, $key)
	{
		$string = $this->_xor_merge($string, $key);
		$dec = '';
		for ($i = 0; $i < strlen($string); $i++)
		{
			$ch = (substr($string, $i++, 1) ^ substr($string, $i, 1));
			$ch = ($ch ^ chr($this->magic_byte));
			$dec .= $ch;
		}
		return $dec;
	}
	
	function _xor_merge($string, $key) { 
		$hash = sha1($key); 
		$str = ''; 
		for ($i = 0; $i < strlen($string); $i++) { 
			$str .= substr($string, $i, 1) ^ substr($hash, (($i+1) % strlen($hash)), 1); 
		} 
		return $str; 
	} 
	
}
