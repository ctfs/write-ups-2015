<?PHP
require_once("./include/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
      <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <title>Home page</title>
      <!-- <link rel="STYLESHEET" type="text/css" href="style/fg_membersite.css"> -->

      <!-- Bootstrap -->
      <link rel="stylesheet" href="style/bootstrap.min.css">
      <link rel="stylesheet" href="style/bootstrap-theme.min.css">
      <script src="scripts/bootstrap.min.js"></script>   
</head>
<body>
<div id='fg_membersite_content' class="container">
<h2>Membership website</h2><hr>
<h3>Home Page</h3>
<p>Welcome back <?= $fgmembersite->UserFullName(); ?>!</p>

<p><a class="btn btn-default" href='change-pwd.php'>Change password</a></p>

<p><a class="btn btn-default" href='logout.php'>Logout</a></p>
</div>
</body>
</html>
