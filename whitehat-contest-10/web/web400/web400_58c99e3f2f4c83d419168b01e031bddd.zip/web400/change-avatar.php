<?PHP
require_once("./include/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
}

if(isset($_POST['submitted']))
{
   if($fgmembersite->UploadAvatar())
   {
        $fgmembersite->RedirectToURL("login-home.php");
   }
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
      <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <title>Change avatar</title>
      <!-- <link rel="STYLESHEET" type="text/css" href="style/fg_membersite.css" /> -->
      <!-- Bootstrap -->
      <link rel="stylesheet" href="style/bootstrap.min.css">
      <link rel="stylesheet" href="style/bootstrap-theme.min.css">
      <script src="scripts/bootstrap.min.js"></script>            
</head>
<body>

<!-- Form Code Start -->
<div id='fg_membersite' class="container">
<h2>Membership website</h2><hr>
<h3>Change Avatar</h3>
<form id='changeavatar' action='<?php echo $fgmembersite->GetSelfScript(); ?>' method='post' accept-charset='UTF-8' enctype="multipart/form-data"  role="form">
<fieldset >

<input type='hidden' name='submitted' id='submitted' value='1'/>

<div class='container form-group'>
	<div class="error"></div>
    <label for='avatar' >Upload Avatar:</label><br/>
    <input type="file" name="avatar" ></input>   
</div>
<!-- 
<br/><br/><br/> -->
<div class='container form-group'>
    <input class="btn btn-default" type='submit' name='Submit' value='Upload' />
</div>
<hr>
<div class='container form-group b-t'>
    <a class="btn btn-default" href='login-home.php'>Home</a>
</div>

</fieldset>
</form>

<script type='text/javascript'>
// <![CDATA[
    

// ]]>
</script>



</div>
<!--
Form Code End (see html-form-guide.com for more info.)
-->

</body>
</html>